# Jupyter Notebook

This is a simple jupyter-notebook application. This application serves as a basic template for jupyter notebooks.

## What does this application do?

This application prints "Hello, World!" to the console.

# How to run?

You can start the application in VS Code by running the following command:

1. Open any notebook (`*.ipynb`) file in editor.
2. Run the notebook using `Run Cell` or `Run All` option from the notebook.

Happy coding! 🙂
